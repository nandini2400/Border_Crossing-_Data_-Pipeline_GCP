from google.cloud import storage, bigquery
import pandas as pd
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)

# Initialize clients
storage_client = storage.Client()
bigquery_client = bigquery.Client()

# Configuration Details
BUCKET_NAME = "team_1_bucket"
FILE_FOLDER = "cross_border/"
PROCESSED_FOLDER = "cross_border/processed/"
PROJECT_NAME = "deductive-anvil-442218-h5"

BRONZE_DATASET = "dataset_bronze"
SILVER_DATASET = "dataset_silver"
GOLD_DATASET = "dataset_gold"


def border_crossing_entry(request):
    """Processes new files uploaded to the Cloud Storage bucket."""
    bucket = storage_client.bucket(BUCKET_NAME)
    blobs = [blob for blob in bucket.list_blobs(prefix=FILE_FOLDER) if blob.name.endswith('.csv')]

    if not blobs:
        logging.info("No CSV files found in the bucket to process.")
        return "No files to process.", 200

    for blob in blobs:
        logging.info(f"Processing new file: {blob.name}")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        bronze_table_id = f"{PROJECT_NAME}.{BRONZE_DATASET}.border_cross_raw_{timestamp}"
        silver_table_id = f"{PROJECT_NAME}.{SILVER_DATASET}.border_cross_clean_{timestamp}"
        gold_table_id = f"{PROJECT_NAME}.{GOLD_DATASET}.border_cross_summary_{timestamp}"

        uri = f"gs://{BUCKET_NAME}/{blob.name}"
        load_to_bigquery(uri, bronze_table_id)
        transform_bronze_to_silver(bronze_table_id, silver_table_id)
        transform_silver_to_gold(silver_table_id, gold_table_id)

        move_to_processed_folder(blob)
        logging.info(f"File {blob.name} processed successfully.")

    return "Processing complete.", 200


def load_to_bigquery(uri, table_id):
    job_config = bigquery.LoadJobConfig(
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,
        autodetect=True,
        write_disposition="WRITE_TRUNCATE"
    )
    load_job = bigquery_client.load_table_from_uri(uri, table_id, job_config=job_config)
    load_job.result()
    logging.info(f"Data loaded to Bronze Layer: {table_id}")


def transform_bronze_to_silver(bronze_table_id, silver_table_id):
    query = f"SELECT * FROM `{bronze_table_id}`"
    df = bigquery_client.query(query).to_dataframe()
    df.columns = [col.lower().replace(" ", "_") for col in df.columns]
    df.to_gbq(silver_table_id, project_id=PROJECT_NAME, if_exists="replace")
    logging.info(f"Data transformed to Silver Layer: {silver_table_id}")


def transform_silver_to_gold(silver_table_id, gold_table_id):
    query = f"""
        SELECT 
            measure,
            SUM(value) AS total_value
        FROM `{silver_table_id}`
        GROUP BY measure
    """
    job_config = bigquery.QueryJobConfig(destination=gold_table_id, write_disposition="WRITE_TRUNCATE")
    query_job = bigquery_client.query(query, job_config=job_config)
    query_job.result()
    logging.info(f"Data aggregated to Gold Layer: {gold_table_id}")


def move_to_processed_folder(blob):
    processed_blob_name = blob.name.replace(FILE_FOLDER, PROCESSED_FOLDER, 1)
    bucket = storage_client.bucket(BUCKET_NAME)
    bucket.rename_blob(blob, processed_blob_name)
    logging.info(f"Moved file to processed folder: {processed_blob_name}")
